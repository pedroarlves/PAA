import pandas as pd
import matplotlib.pyplot as plt
import sys

def plot_comparison(file1, file2, username):
    # Load CSV files
    data1 = pd.read_csv(file1, skipinitialspace=True)
    data2 = pd.read_csv(file2, skipinitialspace=True)

    # Plot
    plt.figure(figsize=(6, 10))  # Adjusted for vertical aspect ratio
    plt.plot(data1['n'], data1['time'], marker='o', label=f"Naive (density={data1['density'].iloc[0]})")
    plt.plot(data2['n'], data2['time'], marker='x', label=f"Tarjan (density={data2['density'].iloc[0]})")

    # Set logarithmic scale for y-axis
    plt.yscale('log')

    # Labels and title
    plt.xlabel('Number of Vertices (n)')
    plt.ylabel('Time (seconds, log scale)')
    plt.title('Algorithm Comparison: Time vs Number of Vertices')
    plt.legend()
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)

    # Save plot as PNG
    output_file = f'data/comparison_{username}.png'
    plt.savefig(output_file)
    print(f"Graph saved as {output_file}")

# Get username from command line argument
if len(sys.argv) < 2:
    print("Error: No username provided.")
    sys.exit(1)

username = sys.argv[1]

plot_comparison(f'data/naive{username}.csv', f'data/tarjan{username}.csv', username)

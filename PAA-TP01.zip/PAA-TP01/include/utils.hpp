#include <cstdlib>

void clearscreen();
int Random(const int& inferiorLimit, const int& superiorLimit);

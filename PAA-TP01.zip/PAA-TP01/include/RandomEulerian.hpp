#ifndef RANDOM_EULERIAN
#define RANDOM_EULERIAN

#include <cstddef>

#include "../DataStructures/include/graph/Graph.hpp"

Graph GenerateRandomEulerian(const size_t&, const float&, const Graph::DataStructures&);
Graph FastGenerateRandomEulerian(size_t n, float density);

#endif

#ifndef FLEURY_NAIVE
#define FLEURY_NAIVE

#include "../DataStructures/include/graph/Graph.hpp"
#include "../DataStructures/include/list/linearList.hpp"
#include "../include/Log.hpp"

LinearList<Vertex> FleuryNaive(const Graph&, Log&);
bool isBridge(const Edge&, bool**, const LinearList<LinearList<Vertex>>&, const Graph&);

#endif

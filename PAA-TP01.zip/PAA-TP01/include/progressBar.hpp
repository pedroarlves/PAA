#include <iostream>
#include <iomanip>
#include <thread>

void progressBar(int i, int li, int ls);

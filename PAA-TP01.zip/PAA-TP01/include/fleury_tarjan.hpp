#ifndef FLEURY_TARJAN
#define FLEURY_TARJAN

#include "../DataStructures/include/graph/Graph.hpp"
#include "../DataStructures/include/list/linearList.hpp"
#include "../include/Log.hpp"

LinearList<Vertex> FleuryTarjan(Graph&, Log&);

#endif

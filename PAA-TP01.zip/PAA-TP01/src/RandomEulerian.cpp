#include "../DataStructures/include/list/linearList.hpp"
#include "../DataStructures/include/graph/Graph.hpp"
#include "../DataStructures/include/graph/GraphBuilder.hpp"
#include "../DataStructures/utils/UnionFind.hpp"
#include "../include/timer.hpp"

#include "../include/RandomEulerian.hpp"
#include "../include/colorMessages.hpp"
#include "../include/progressBar.hpp"
#include "../include/utils.hpp"

#include <format>

// TODO: Implementar com o esquema arvore geradora + rejection sampling
// TODO Pass the data structure choice
Graph GenerateRandomEulerian(const size_t& n, const float& density, const Graph::DataStructures& choice) {

	float minDensity = (2.0 * n - 2) / (n * n - n);

	if (density < minDensity) {
		throw std::runtime_error(std::format("Density must be greater than {}", minDensity));
	}

	if (n % 2 == 0 && density == 1) {
		throw std::runtime_error("Density must be less than 1 for even values of N\n");
	}

	std::cout << "Starting the Data Structure" << std::endl;

	Timer timer;

	timer.start();

	Graph G = GraphBuilder()
		.dataStructure(choice)
	.build();

	LinearList<Vertex> D(n, 0);
	UnionFind<Vertex> uf;

	for (Vertex v = 0; v < n; v++) {
		uf.insert(v);
		G.addVertex(v);
	}

	const LinearList<Vertex> vertices = G.vertices();

	int k = n + ((n % 2) - 2);

	int contador = 0, colisions = 0;
	int m = ((n * n - n) / 2.0) * density;

	std::cout << "Generating a Random Eulerian Graph" << std::endl;

	// WARNING: sera que existe a chance desse while rodar pra sempre?
	while (contador < m) {

		Vertex u = Random(0, n - 1);
		Vertex v = Random(0, n - 1);

		if (u != v && !G.hasEdge({v, u}) && D[u] < k && D[v] < k) {

			uf.join(u, v);
			G.addEdge({u, v});
			D[u]++, D[v]++;

			if (n >= 100 && contador % (m / 100) == 0) {
				progressBar(contador, 0, m);
			}

			contador++;
		}

		else {
			colisions++;
			std::cout << std::format("u: {}, v: {}", u, v) << std::endl;
			std::cout << std::format("G.n: {}, G.m: {}, G.density: {}, n: {}", G.n, G.m, G.density(10), n) << std::endl;
		}
	}

	std::cout << std::endl << "colisions: " << colisions << std::endl;
	std::cout << "G.density(): " << G.density() << std::endl;

	// TODO:
	if (uf.numberOfSets() > 1) {

		std::cout << "Nao e um grafo conexo" << std::endl;

		LinearList<Vertex> heads = uf.heads();

		Vertex u = heads[0];

		for (int i = 1; i < heads.size(); i++) {
			Vertex v = heads[i];
			uf.join(u, v);
			G.addEdge({u, v});
			D[u]++, D[v]++;
		}

		std::cout << "Agora e um grafo conexo" << std::endl;
	}

	LinearList<Vertex> oddDegree(n);

	for (Vertex v : vertices) {
		if (D[v] % 2 == 1) oddDegree += v;
	}

	for (int i = 0; i < oddDegree.size(); i += 2) {

		Vertex u = oddDegree[i], v = oddDegree[i + 1];

		if (!G.hasEdge({u, v})) {
			G.addEdge({u, v});
			D[u]++, D[v]++;
		}

		else if (D[u] == 1 || D[v] == 1) {

			Vertex w;

			for (Vertex x : vertices) {
				if (D[x] % 2 == 0 && D[x] < k - 1) {
					w = x;
					break;
				}
			}

			G.addEdge({u, w});
			G.addEdge({w, v});

			D[u]++, D[v]++, D[w] += 2;
		}

		else {
			G.removeEdge({u, v});
			D[u]--, D[v]--;
		}
	}

	bool aux = false;

	for (Vertex v : vertices) {
		if (D[v] % 2 == 1) {
			aux = true;
			std::cout << std::format("D[{}]: {}", v, D[v]) << std::endl;
		}
	}

	std::cout << "After making eulerian G.density(): " << G.density() << std::endl;

	if (!aux) {
		// std::cout << "E euleriano!!!" << std::endl;
	}

	else std::cout << "Nao e euleriano :(" << std::endl;

    Color red = {255, 0, 0};
    Color green = {0, 255, 0};

	printColoredMessage(green, red, 0.0, 10, timer.result(), std::format("{}s", timer.result()));

	return G;
}

Graph FastGenerateRandomEulerian(size_t n, float density) {

	float minDensity = (2.0 * n - 2) / (n * n - n);

	if (density < minDensity) {
		throw std::runtime_error(std::format("Density must be greater than {}", minDensity));
	}

	if (n % 2 == 0 && density == 1) {
		throw std::runtime_error("Density must be less than 1 for even values of N");
	}

	std::cout << "Generating a Random Eulerian Graph" << std::endl;

	Timer timer;

	timer.start();

	Graph G = GraphBuilder()
		.dataStructure(Graph::AdjacencyMatrix)
	.build();

	LinearList<Vertex> D(n, 0);
	UnionFind<Vertex> uf;

	for (Vertex v = 0; v < n; v++) {
		uf.insert(v);
		G.addVertex(v);
		progressBar(v, 0, n);
	}

	int k = n + ((n % 2) - 2);
	int m = ((n * n - n) / 2.0) * density;

	LinearList<Edge> edges(m);
	int contador = 0;

	for (int u = 0; contador < m && u < n - 1; u++) {
		for (int v = u + 1; contador < m && v < n; v++) {
			// edges += {u, v};
			G.addEdge({u, v});
			contador++;
			progressBar(contador, 0, m);
		}
	}

	//    for (int i = m - 1; i >= 0; i--) {
	//
	// 	std::swap(edges[i], edges[Random(0, i)]);
	//
	// 	Vertex u = edges[i].u;
	// 	Vertex v = edges[i].v;
	//
	// 	G.addEdge({u, v});
	// 	uf.join(u, v);
	// 	D[u]++, D[v]++;
	// 	progressBar((m - 1) - i, n - 1, m);
	// }

	std::cout << "G.density(): " << G.density() << std::endl;

	// TODO:
	if (uf.numberOfSets() > 1) {

		std::cout << "Nao e um grafo conexo" << std::endl;

		// for (Vertex v : uf.heads()) {
		//
		// }
	}

	else {
		std::cout << "É um grafo conexo!" << std::endl;
	}

	LinearList<Vertex> oddDegree(n);

	for (Vertex v : G.vertices()) {
		if (D[v] % 2 == 1) oddDegree += v;
	}

	for (int i = 0; i < oddDegree.size(); i += 2) {

		Vertex u = oddDegree[i], v = oddDegree[i + 1];

		if (!G.hasEdge({u, v})) {
			G.addEdge({u, v});
			D[u]++, D[v]++;
		}

		else if (D[u] == 1 || D[v] == 1) {

			Vertex w;

			for (Vertex x : G.vertices()) {
				if (D[x] % 2 == 0 && D[x] < k - 1) {
					w = x;
					break;
				}
			}

			G.addEdge({u, w});
			G.addEdge({w, v});

			D[u]++, D[v]++, D[w] += 2;
		}

		else {
			G.removeEdge({u, v});
			D[u]--, D[v]--;
		}
	}

	bool aux = false;

	for (Vertex v : G.vertices()) {
		if (D[v] % 2 == 1) {
			aux = true;
			std::cout << std::format("D[{}]: {}", v, D[v]) << std::endl;
		}
	}

	if (!aux) {
		std::cout << "É euleriano!!!" << std::endl;
	}

	else std::cout << "Não é euleriano :(" << std::endl;


    Color red = {255, 0, 0};
    Color green = {0, 255, 0};

	printColoredMessage(green, red, 0.0, 10, timer.result(), std::format("{}s", timer.result()));

	return G;
}

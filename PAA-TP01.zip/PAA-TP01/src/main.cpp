#include <cmath>
#include <format>
#include <iostream>

using namespace std;

#include "../include/utils.hpp"
#include "../include/RandomEulerian.hpp"
#include "../DataStructures/include/graph/Graph.hpp"

#include "../include/Log.hpp"
#include "../include/fleury_naive.hpp"
#include "../include/fleury_tarjan.hpp"

constexpr string username = "Lucas";

void GenerateGraphics() {

    string command = "python3 scripts/Graphic.py " + username;

    int result = system(command.c_str());

    if (result != 0) {
        throw runtime_error("Error: Failed to run Python script.\n");
    }
}

void foo(const size_t& n, const double& density, Log& naiveLog, Log& tarjanLog) {

	Graph G = GenerateRandomEulerian(n, density, Graph::FastAdjacencyList);

	cout << format("G.n: {}, G.m: {}, G.density: {}", G.n, G.m, G.density(10)) << endl;

	FleuryNaive(G, naiveLog);
	// FleuryNaive(G, tarjanLog);
	
	cout << "--------------------------" << endl;
}

int main() {

	clearscreen();

	Log naiveLog, tarjanLog;

	foo(100, 0.1, naiveLog, tarjanLog);
	foo(1'000, 0.005, naiveLog, tarjanLog);
	foo(10'000, 0.0005, naiveLog, tarjanLog);
	foo(100'000, 0.00005, naiveLog, tarjanLog);

	naiveLog.save("naive" + username);
	tarjanLog.save("tarjan" + username);

	GenerateGraphics();

	return 0;
}

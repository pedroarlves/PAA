#include "../include/fleury_naive.hpp"

#include "../DataStructures/include/stack/linkedStack.hpp"
#include "../DataStructures/include/matrix/matrix.hpp"
#include "../include/progressBar.hpp"
#include "../include/utils.hpp"

bool isBridge(const Edge& e, const Matrix<bool>& visitedEdges, const LinearList<LinearList<Vertex>>& neighbors, const Graph& G) {

	LinkedStack<Vertex> stack;

	LinearList<bool> visited(G.n, false);

	visited[e.u] = true;

	for (Vertex v : neighbors[e.u]) {
		if (v != e.v && !visitedEdges[e.u][v]) {
			stack.push(v);
			visited[v] = true;
		}
	}

	while (!stack.empty()) {

		Vertex u = stack.pop();

		for (Vertex v : neighbors[u]) {

			if (v == e.v) return false;

			if (!visited[v] && !visitedEdges[u][v]) {
				stack.push(v);
				visited[v] = true;
			}
		}
	}

	return true;
}

LinearList<Vertex> FleuryNaive(const Graph& G, Log& log) {

	std::cout << "Fleury Naive: Starting Data Structures" << std::endl;;

	Matrix<bool> visitedEdges(true, G.n, G.n); // V * V = O(V)

	LinearList<Vertex> eulerianCycle(G.m + 1), D(G.n, 0); // G.n = O(n)

	LinearList<LinearList<Vertex>> neighbors(G.n, {});

	const LinearList<Vertex> vertices = G.vertices();

	for (Vertex v : vertices) {
		neighbors[v] = G.neighbors(v);
	}

	Vertex u = Random(0, G.n - 1); // 4 = O(1)

	for (Vertex v : vertices) { // V * (V + 1 + 3) = V² + 4V = O(V²)

		D[v] = G.degree(v); // G.n + 1 (att) = O(V)

		if (D[v] % 2 == 1) u = v; // 3 = O(1)
	}

	eulerianCycle += u; // 2 = O(1)

	int count = 0; // 2 = O(1)

	// O(E) * O(V) * (V + E) = O(EV² + E²V) = O(VE²)

	std::cout << "Fleury Naive: Starting Algorithm" << std::endl;;

	log.startTimer();

	for (int i = 0; i < G.m; i++) { // E = O(E)

		if (G.n >= 100 && i % (G.m / 100) == 0) {
			progressBar(i, 0, G.m);
		}

		for (Vertex v : neighbors[u]) { // d(v) = O(V)

			if (!visitedEdges[u][v]) { // ? = O(1)

				bool bridge; // 1 = O(1)

				if (D[u] > 1) { // 2 = O(1)
					bridge = isBridge({u, v}, visitedEdges, neighbors, G); // 1 + O(V + E) = O(V + E)
					count++; // 2 = O(1)
				}

				if (D[u] == 1 || !bridge) { // 4 = O(1)

					visitedEdges[u][v] = true; // ? + 1 = O(1)
					visitedEdges[v][u] = true; // ? + 1 = O(1)
					D[u]--, D[v]--; // 2 * ? + 2 = O(1)

					eulerianCycle += v; // 2 
					u = v; // 1 = O(1)

					break; // 1 = O(1)
				}
			}
		}
	}

	log.stopTimer();
	log.registrar(G.n, G.m, G.density());

	std::cout << "\ncountFleury: " << count << std::endl;

	// return eulerianCycle;
	return {};
}

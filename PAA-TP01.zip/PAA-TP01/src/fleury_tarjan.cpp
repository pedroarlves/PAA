#include "../include/fleury_tarjan.hpp"
#include "../DataStructures/include/matrix/matrix.hpp"
#include "../DataStructures/include/stack/linkedStack.hpp"
#include "../include/progressBar.hpp"
#include "../include/utils.hpp"

#include <format>

#define DEBUGGING false

void TarjanIterative(Matrix<bool>& bridges, Graph& G) {

	LinearList<int> disc(G.n, -1), low(G.n, -1), parent(G.n, -1);

	LinkedStack<Vertex> stack = { 0 };

	int time = 0;

	while (!stack.empty()) {

		Vertex u = stack.pop();

		if (disc[u] == -1) stack.push(u);

		for (Vertex v : G.neighbors(u)) {

			if (disc[v] == -1) {

				if (disc[u] == -1) {

					parent[v] = u;

					stack.push(v);
				}

				else {

					low[u] = std::min(low[u], low[v]);

					if (low[v] > disc[u]) {

						bridges[u][v] = true;
						bridges[v][u] = true;

						std::cout << std::format("{{{}, {}}} is a bridge!", u, v) << std::endl;

						if (DEBUGGING) {
							G.changeEdgeProps({u, v}, {"red", "dotted"});
						}
					}
				}
			}

			else if (v != parent[u]) low[u] = std::min(low[u], disc[v]);
		}

		if (disc[u] == -1) {
			disc[u] = low[u] = time++;
		}
	}
}

void DFS(Vertex u, const Matrix<bool>& visitedEdges, LinearList<int>& disc, LinearList<int>& low, LinearList<Vertex>& parent, Matrix<bool>& bridges, LinearList<LinearList<Vertex>>& neighbors, Graph& G) {

    static int time = 0;

    disc[u] = low[u] = time++;

    for (Vertex v : neighbors[u]) {

        if (disc[v] == -1 && !visitedEdges[u][v]) {  // If v is not visited

            parent[v] = u;

            DFS(v, visitedEdges, disc, low, parent, bridges, neighbors, G);

            low[u] = std::min(low[u], low[v]);

            // Bridge condition
            if (low[v] > disc[u]) {

                bridges[u][v] = true;
                bridges[v][u] = true;

                if (DEBUGGING) {
                    std::cout << std::format("\n{{{}, {}}} is a bridge!", u, v) << std::endl;
                    G.changeEdgeProps({u, v}, {"red", "dotted"});
                }
            }
        }

        // Update low value for back edges
        else if (v != parent[u]) {
            low[u] = std::min(low[u], disc[v]);
        }
    }
}

void iterativeDFS(Vertex start, LinearList<int>& disc, LinearList<int>& low, LinearList<Vertex>& parent, Matrix<bool>& bridges, Graph& G) {

    static int time = 0;
    LinkedStack<Pair<Vertex, int>> stack; // Pair: (current vertex, next neighbor index)
    stack.push({start, 0});
    disc[start] = low[start] = time++;

    while (!stack.empty()) {

        auto [u, neighborIdx] = stack.pop();
        bool processed = false;

        auto neighbors = G.neighbors(u);

        for (int i = neighborIdx; i < neighbors.size(); ++i) {

            Vertex v = neighbors[i];

			if (disc[v] == -1) { // If v is not visited
				parent[v] = u;
				disc[v] = low[v] = time++;
				stack.push({u, i + 1}); // Save current state
				stack.push({v, 0});     // Start DFS on v
				processed = true;
				break;
			}

			else if (v != parent[u]) { // Back edge
				low[u] = std::min(low[u], disc[v]);
			}
		}

		if (!processed) { // All neighbors processed

			if (parent[u] != -1) {

				low[parent[u]] = std::min(low[parent[u]], low[u]);

				if (low[u] > disc[parent[u]]) { // Bridge condition

					bridges[u][parent[u]] = true;
					bridges[parent[u]][u] = true;

					if (DEBUGGING) {
                        std::cout << std::format("{{{}, {}}} is a bridge!", u, parent[u]) << std::endl;
                        G.changeEdgeProps({u, parent[u]}, {"red", "dotted"});
                    }
                }
            }
        }
    }
}

void Tarjan(Vertex start, Matrix<bool>& bridges, const Matrix<bool>& visitedEdges, LinearList<LinearList<Vertex>>& neighbors, Graph& G) {

    LinearList<int> disc(G.n, -1), low(G.n, -1), parent(G.n, -1);

    DFS(start, visitedEdges, disc, low, parent, bridges, neighbors, G);
}

LinearList<Vertex> FleuryTarjan(Graph& G, Log& log) {

	Matrix<bool> visitedEdges(true, G.n, G.n), bridges(true, G.n, G.n);

    Vertex start = Random(0, G.n - 1);

	LinearList<Vertex> eulerianCycle(G.m + 1), D(G.n, 0);

	Vertex u = Random(0, G.n - 1);

	LinearList<LinearList<Vertex>> neighbors(G.n, {});

	const LinearList<Vertex> vertices = G.vertices();

	for (Vertex v : vertices) {
		neighbors[v] = G.neighbors(v);
	}

	Tarjan(start, bridges, visitedEdges, neighbors, G);

	for (Vertex v : vertices) {

		D[v] = G.degree(v);

		if (D[v] % 2 == 1) u = v;
	}

	eulerianCycle += u;

	int count = 0;

	log.startTimer();

	for (int i = 0; i < G.m; i++) {

		if (G.n >= 100 && i % (G.m / 100) == 0) {
			progressBar(i, 0, G.m);
		}

		for (Vertex v : neighbors[u]) {

			if (!visitedEdges[u][v]) {

				if (D[u] > 1 && !bridges[u][v]) {
					Tarjan(u, bridges, visitedEdges, neighbors, G);
					count++;
				}

				if (D[u] == 1 || !bridges[u][v]) {

					visitedEdges[u][v] = true;
					visitedEdges[v][u] = true;

					D[u]--, D[v]--;
					eulerianCycle += v;
					u = v;

					break;
				}
			}
		}
	}

	log.stopTimer();
	log.registrar(G.n, G.m, G.density());

	std::cout << "\ncountTarjan: " << count << std::endl;

	return eulerianCycle;
}

#include <iostream>

#include "../DataStructures/utils/timer.hpp"
#include "../DataStructures/include/graph/Graph.hpp"
#include "../DataStructures/include/graph/GraphBuilder.hpp"

#include "../include/RandomEulerian.hpp"

#include "../include/fleury_naive.hpp"
#include "../include/fleury_tarjan.hpp"

using namespace std;

int main() {

	int n = 7;

	Graph G = GraphBuilder()
		.dataStructure(Graph::AdjacencyMatrix)
	.build();

	for (int i = 0; i < 7; i++) {
		G.addVertex(i);
	}

	G.addEdge({0, 1});
	G.addEdge({0, 4});
	G.addEdge({1, 2});
	G.addEdge({1, 4});
	G.addEdge({2, 3});
	G.addEdge({2, 6});
	G.addEdge({3, 6});
	G.addEdge({4, 5});
	G.addEdge({5, 6});

	// Graph G = GenerateRandomEulerian(n, .25);

	LinearList<Vertex> eulerianCycleTarjan, eulerianCycleNaive;

	Timer timer;

	timer.start();
	eulerianCycleTarjan = FleuryTarjan(G);
	timer.stop();

	cout << format("\nTarjan timer: {:.3f}s", timer.result()) << endl;

	timer.start();
	eulerianCycleNaive = FleuryNaive(G);
	timer.stop();

	cout << format("\nNaive timer: {:.3f}s", timer.result()) << endl;

	if (eulerianCycleNaive == eulerianCycleTarjan) {
		cout << "Caminhos encontrados são iguais!" << endl;
	}

	else {
		cout << "Caminhos encontrados são diferentes!" << endl;
	}

	cout << "FIM DO ALGORITMO" << endl;

	return 0;
}
